# Hospital_Emergency_Room_Dashboard
I have created dashboard to find out meaningful insights on Hospital Emergency Room data
<br>

<img src="https://github.com/SatishDhawale/Hospital_Emergency_Room_Dashboard/blob/4ed886d2946467c75855e21291b18d07011c7189/Hospital%20Dashboard%20Final%20.jpg" alt="Image Description" width="600">
<br><br>
Watch Video  : Video Tutotial is coming soon

